public class SnakeApp {
    public static void main(String[] args) {
        SnakeGUI gui = new SnakeGUI();
        gui.setUpGUI();
        gui.setUpKeyListener();
    }
}